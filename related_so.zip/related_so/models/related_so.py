from odoo import api, fields, models, Command

class AccountMove(models.Model):
    '''inheriting the invoice here and add additional field related so.
    when the customer doing the invoice, they can add their to 'invoice' stage
    orders sale order lines to single invoice line '''

    _inherit = 'account.move'

    related_so_ids = fields.Many2many('sale.order',string='Related SO')


    def action_post(self):
        '''its an existing function in invoice,before the original function work
        below code will run and then super will called. Sale order lines fetching
        into invoice order line here'''
        for record in self:
            for sale_order in record.related_so_ids:

                # status of the selected sale order changed to invoiced stage
                self.related_so_ids.invoice_status = 'invoiced'
                for order_line in sale_order.order_line:
                    invoice_line_vals = {
                        'product_id':order_line.product_id.id,
                        'quantity':order_line.product_uom_qty,
                        'price_unit':order_line.price_unit,
                        'tax_ids':order_line.tax_id,
                        'price_subtotal':order_line.price_subtotal,}
                    record.update({'invoice_line_ids': [Command.create(invoice_line_vals)]})
        super().action_post()













    #
    # class AccountMove(models.Model):
    #     _inherit = 'account.move'
    #
    #     def _add_order_lines_to_invoice(self):
    #         for invoice in self:
    #             # Clear existing invoice lines to avoid duplication (optional)
    #             invoice.invoice_line_ids = [(5, 0, 0)]
    #
    #             for sale_order in invoice.related_so_ids:
    #                 for order_line in sale_order.order_line:
    #                     if order_line.qty_to_invoice > 0:  # Ensure there are invoiceable quantities
    #                         invoice_line_vals = {
    #                             'product_id': order_line.product_id.id,
    #                             'name': order_line.name,
    #                             'quantity': order_line.qty_to_invoice,
    #                             'price_unit': order_line.price_unit,
    #                             'discount': order_line.discount,
    #                             'tax_ids': [(6, 0, order_line.tax_id.ids)],
    #                             'sale_order_line_id': order_line.id,
    #                         }
    #                         invoice.write({'invoice_line_ids': [
    #                             (0, 0, invoice_line_vals)]})

    # def


