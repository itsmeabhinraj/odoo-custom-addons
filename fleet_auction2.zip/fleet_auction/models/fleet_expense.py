from odoo import fields,models

class FleetExpense(models.Model):
    _name = 'fleet.expense'
    _description = 'fleet auction expenses listed here'

    name = fields.Char("Description")
    expense_amount = fields.Monetary("Amount",copy=False)
    currency_id = fields.Many2one('res.currency', string="Currency",
                                  default=lambda self: self.env.user.company_id.currency_id.id)
    auction_id = fields.Many2one('fleet.auction.auction',required=True,
                                 copy=False,readonly=True,ondelete='cascade')
    # total = fields.Monetary("Total",compute="_compute_total_expense")

    # def _compute_total_expense(self):
    #     print('123')
    #     for record in self:
    #         record.total = sum(record.expense_amount)