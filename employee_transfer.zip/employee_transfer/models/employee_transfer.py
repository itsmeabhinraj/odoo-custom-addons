from email.policy import default

from odoo import api,fields,models

class EmployeeTransfer(models.Model):
    _name = 'employee.transfer'

    name = fields.Char("Name")
    employee_id = fields.Many2one('hr.employee',string='Employee')
    current_company_id = fields.Many2one('res.company', store=True,
                                         copy=False, string="Current Company",
                                         readonly=True,
                                         default=lambda self: self.env.company.id)
    choosen_company_id = fields.Many2one('res.company',store=True, string='Transfer company',default=lambda self: self.env.company.id)
    transfer_state = fields.Selection(
        string="State", selection=[('to_submit', 'To submit'),
                                   ('submitted', 'Submitted'),
                                   ('approved', 'Approved')], default='to_submit')
    def submit_request(self):
        self.transfer_state =='submitted'
        print("sub")

    def confirm_request(self):
        print('con')

    def refuse_request(self):
        print('ref')

    def cancel_request(self):
        print('Cancel')