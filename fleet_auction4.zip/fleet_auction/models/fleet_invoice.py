from odoo import fields,models

class FleetInvoice(models.Model):
    # _name = 'fleet.invoice'
    _inherit = 'account.move'

    auction_id = fields.Many2one('fleet.auction.auction')
    payment_status = fields.Selection(
        string='Paid status',
        selection=[('notpaid','Not Paid'),
                   ('paid','Paid')],
        default = 'notpaid'
    )


    def action_post(self):
        template = self.env.ref('account.email_template_edi_invoice')
        template.send_mail(self.id,force_send=True)
        super().action_post()



