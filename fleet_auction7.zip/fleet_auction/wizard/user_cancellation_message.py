from odoo import fields,models

class UserCancellationMessage(models.TransientModel):
    _name ='user.cancellation.message'


    auction_id = fields.Many2one('fleet.auction.auction')
    reason = fields.Text("Reason for cancelation",store=True)

    def function1(self):
        print(self)
        self.env['fleet.auction.auction'].auction_cancel()

