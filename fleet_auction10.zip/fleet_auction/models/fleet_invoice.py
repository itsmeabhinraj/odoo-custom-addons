# -*- coding: utf-8 -*-
from odoo import fields,models
from odoo.api import readonly


class FleetInvoice(models.Model):
    # _name = 'fleet.invoice'
    _inherit = 'account.move'

    auction_id = fields.Many2one('fleet.auction.auction')
    payment_status = fields.Selection(
        string='Paid status',
        selection=[('notpaid','Not Paid'),
                   ('paid','Paid')],
        default = 'notpaid',readonly=True
    )


    def action_post(self):
        super().action_post()
        # template = self.env.ref('account.email_template_edi_invoice')
        # template.send_mail(self.id,force_send=True)

    # def action_create_payments(self):
    #     self.payment_status == 'paid'
    #     print('qqsawdawdx')
    #     super(FleetInvoice,self).action_create_payments()



