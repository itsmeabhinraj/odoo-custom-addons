{
    'name': 'Fleet Auction',
    'version': '1.2',
    'application': True,
    'category': 'vechicle',
    'depends':['base','hr','mail','fleet','crm'],
    'data': [
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'views/fleet_vehicle.xml',
        'views/fleet_bid_view.xml',
        'views/fleet_auction_view.xml',
        'views/fleet_auction_menu.xml',
    ]
}