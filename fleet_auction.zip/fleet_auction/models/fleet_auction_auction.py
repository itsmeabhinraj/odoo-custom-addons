from email.policy import default
from odoo import  _

from pkg_resources import require
from setuptools.windows_support import hide_file

from odoo import models, fields, api,_
from odoo.addons.test_convert.tests.test_env import record
from odoo.exceptions import ValidationError, UserError
from odoo.fields import Selection


class FleetAuctionAuction(models.Model):
    _name = 'fleet.auction.auction'
    _description = 'fleet auction details'
    _inherit = 'mail.thread','mail.activity.mixin'

    name = fields.Char(string="Fleet Reference", readonly=True,default=lambda self: _('New'))
    vehicle_name = fields.Many2one("fleet.vehicle",required=True,copy=False)
    brand = fields.Char('Brand')
    start_date = fields.Date("Start date")
    end_date = fields.Date("End date")
    active = fields.Boolean('Active',default=11)
    fleet_auction_state = fields.Selection(
        string='State',
        selection=[('draft','Draft'),('ongoing','Ongoing'),('confirmed','Confirmed'),('success','Success'),('canceled','Canceled')],
        default='draft',track_visibility='onchange'
    )
    image = fields.Image("Image")
    company_id = fields.Many2one('res.company', store=True, copy=False,
                                 string="Company",
                                 default=lambda self: self.env.user.company_id.id)
    currency_id = fields.Many2one('res.currency', string="Currency",
                                  default=lambda self: self.env.user.company_id.currency_id.id)
    start_price = fields.Monetary('Start price',copy=False)
    won_price = fields.Monetary('Won price',copy=False)
    responsible = fields.Many2one('hr.employee',required=True, string="Responsible",
                                  default=lambda self: self.env.user.id)
    description = fields.Html("vehicle description")
    customer_id = fields.Many2one("res.partner",string="Customer")

    # customer_id=fields.Many2one("fleet.bid",String="Customer")
    customer_phone = fields.Char(related='customer_id.phone',readonly=False)
    customer_email = fields.Char(related='customer_id.email',readonly=False)
    street = fields.Char(related='customer_id.street',readonly=False)
    street2 = fields.Char(related='customer_id.street2',readonly=False)
    city = fields.Char(related='customer_id.city',readonly=False)
    state_id = fields.Many2one(related='customer_id.state_id',readonly=False)
    zip = fields.Char(related='customer_id.zip',readonly=False)
    country_id = fields.Many2one(related='customer_id.country_id',readonly=False)
    bid_ids= fields.One2many("fleet.bid","auction_id")
    best_bid = fields.Float(string="bid")
    same_bid = fields.Char(string="Auction_bid")

    @api.model
    def create(self,vals_list):
        """Sequance code are created here.name is the sequance field name """
        vals_list['name'] = self.env['ir.sequence'].next_by_code('fleet.auction')
        return super().create(vals_list)

    @api.model
    @api.constrains('start_date','end_date')
    def date_constrains(self):
        """applying validation for start_date of auction and end_date.If the selected
        date end_date is before the start_date a error popup apprears"""
        for record in self:
            if record.start_date>record.end_date:
                raise ValidationError(_("Date should be apply before end"))

    def auction_cancel(self):
        """while Cancel auction button triggered state changes to canceled"""
        if self.fleet_auction_state == 'success':
            raise UserError('An error occured,Already auction success')
        self.fleet_auction_state = 'canceled'


    def auction_end(self):
        """while End Auction button triggered state changed to success"""
        if self.fleet_auction_state=='canceled':
            raise UserError("Error--- already canceled")
        self.fleet_auction_state = 'success'
        best = self.bid_ids
        sorted_value = best.sorted(lambda best:best.bid_price, reverse=True)
        self.won_price = sorted_value[0].bid_price
        self.customer_id = sorted_value[0].bid_customer_id

    def auction_confirm(self):
        """While Confirm button triggered state changes to Confirmed"""
        if self.fleet_auction_state == 'canceled':
            raise UserError("Error--- already canceled")
        self.fleet_auction_state = 'confirmed'

        # for record in self:
        #     record.same_bid = record.bid_ids.mapped('auction_id')
        #     record.best_bid = max(record.bid_ids.mapped('bid_price')) if record.bid_ids else 0
        #     if (record.start_price < record.best_bid):
        #         record.won_price=record.best_bid
        #         record.customer_id=record.bid_ids.bid_customer_id
        # record.best_price = max(record.offer_ids.mapped('price')) if record.offer_ids else 0

    def auction_reset(self):
        """while Reset button triggerd state chnage back to draft form"""
        self.fleet_auction_state='draft'


