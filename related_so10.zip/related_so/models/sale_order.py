from odoo import api,fields, models


class AccountMove(models.Model):
    _inherit = 'sale.order'

    # invoice_ids = fields.Many2many(string="Invoices",comodel_name='account.move',compute='_compute_origin_so_count')
    # invoice_count = fields.Integer(string="Invoice Count",compute='_compute_origin_so_count')

    # @api.depends('invoice_ids')
    # def _compute_origin_so_count(self):
    #     for move in self:
    #         move.invoice_count = len(move.invoice_ids)
    #         print(move.invoice_count)

    def action_view_invoice(self):
        action = super().action_view_invoice()
        invoices = self.mapped('invoice_ids') and self.mapped(
            'invoice_line_ids.sale_line_ids.order_id')
        action['domain'] = [('id', 'in', invoices.ids)]
        # print(self.invoice_ids.related_so_ids.ids)
        return action












